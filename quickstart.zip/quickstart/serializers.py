# from django.contrib.auth.models import Group
from rest_framework import serializers
from .models import User, SignUp


class UserSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = User
        fields = ('user_id', 'nickname', 'comment')


class SignUpSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = SignUp
        fields = ('user_id', 'password')


# class GroupSerializer(serializers.HyperlinkedModelSerializer):
#     class Meta:
#         model = Group
#         fields = ('a', 'b','c')